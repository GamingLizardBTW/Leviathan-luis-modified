
#include <rpygen_wrapper.hpp>

RPYBUILD_PYBIND11_MODULE(m) {
    initWrapper(m);
}