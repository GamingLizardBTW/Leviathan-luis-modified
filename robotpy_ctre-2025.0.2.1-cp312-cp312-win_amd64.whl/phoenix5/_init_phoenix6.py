from phoenix6.phoenix_native import Native

Native.instance()
