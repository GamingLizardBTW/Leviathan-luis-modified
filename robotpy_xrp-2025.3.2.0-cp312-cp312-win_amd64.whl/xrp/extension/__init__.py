from .main import loadExtension

__all__ = ["loadExtension"]
